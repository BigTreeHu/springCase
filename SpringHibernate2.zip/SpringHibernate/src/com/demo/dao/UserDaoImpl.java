package com.demo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.demo.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private HibernateTemplate template;
	
//	private Session session;
//	private Transaction tx;
	
	@Override
	public List<User> findUsers(String hql) {
		return (List<User>) template.find(hql, null);
	}

	@Override
	public void addUser(User user) {
		template.save(user);
	}

	@Override
	public void deleteUser(User user) {
		template.delete(user);
	}

	@Override
	public void updateUser(User user) {
		template.update(user);
	}

}
