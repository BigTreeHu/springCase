package com.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.model.User;

public interface UserDao {
	/**
	 * ��ѯ
	 * @param hql
	 * @return
	 */
	public List<User> findUsers(String hql);
	/**
	 * ����
	 * @param user
	 */
	public void addUser(User user);
	/**
	 * ɾ��
	 * @param user
	 */
	public void deleteUser(User user);
	/**
	 * �޸�
	 * @param user
	 */
	public void updateUser(User user);
}
