package com.demo.service;

import java.util.List;

import com.demo.model.User;

public interface UserService {
	/**
	 * ��ѯ
	 * @param hql
	 * @return
	 */
	public List<User> findUsers(String hql);
	/**
	 * ����
	 * @param user
	 */
	public void addUser(User user);
	/**
	 * ɾ��
	 * @param user
	 */
	public void deleteUser(User user);
	/**
	 * �޸�
	 * @param user
	 */
	public void updateUser(User user);
}
