package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.UserDao;
import com.demo.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userdao;
	
	@Override
	public List<User> findUsers(String hql) {
		return userdao.findUsers(hql);
	}

	@Override
	@Transactional
	public void addUser(User user) {
		userdao.addUser(user);
	}

	@Override
	public void deleteUser(User user) {
		userdao.deleteUser(user);
	}

	@Override
	public void updateUser(User user) {
		userdao.updateUser(user);
	}

}
