package com.util;





import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.User;
import com.demo.service.UserService;
import com.demo.service.UserServiceImpl;

public class SHTest {

	ApplicationContext ac;
	@Before
	public void init(){
		ac = new ClassPathXmlApplicationContext("ApplicationContext.xml");
	}
	@Test
	public void saveUserTest() {
		UserService service = ac.getBean(UserServiceImpl.class);
		User user = new User();
		user.setUsername("����");
		user.setUsersex("M");
		user.setUserage(20);
		service.addUser(user);
	}
	
	@Test
	public void findUsersTest(){
		UserService service = ac.getBean(UserServiceImpl.class);
		List<User> ulist = service.findUsers("from User");
		for (User user : ulist) {
			System.out.println(user);
		}
	}

}
