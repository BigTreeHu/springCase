package com.demo.util;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.demo.model.dept;
import com.demo.model.users;

public class hibernatetest {

	private SessionFactory sf;
	private Session session;
	private Transaction tx;
	@Before
	public void init() {
		Configuration con = new Configuration().configure();
		sf = con.buildSessionFactory();
		session = sf.openSession();
		tx = session.beginTransaction();
	}
	@Test
	public void savetest() {
		dept dept = new dept();
		dept.setDname("aa");
		
		users users1 = new users();
		users1.setUsername("123456");
		users1.setUserpwd("456789");
		users1.setEmail("123@qq.com");
		
		users users2 = new users();
		users2.setUsername("654321");
		users2.setUserpwd("987654");
		users2.setEmail("321@qq.com");
		dept.getUsers().add(users1);
		dept.getUsers().add(users2);
		session.save(dept);
	}
	@After
	public void close() {
		tx.commit();
		session.close();
		sf.close();
	}

}
