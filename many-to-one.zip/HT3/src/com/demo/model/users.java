package com.demo.model;

public class users {

	private Integer userid;
	private String username;
	private String userpwd;
	private String email;
	private dept dept;
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public dept getDept() {
		return dept;
	}
	public void setDept(dept dept) {
		this.dept = dept;
	}
}
