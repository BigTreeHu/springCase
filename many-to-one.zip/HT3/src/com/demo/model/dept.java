package com.demo.model;

import java.util.HashSet;
import java.util.Set;

public class dept {
	private Integer did;
	private String dname;
	private Set<users> users = new HashSet<users>();
	public Set<users> getUsers() {
		return users;
	}
	public void setUsers(Set<users> users) {
		this.users = users;
	}
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	

}
